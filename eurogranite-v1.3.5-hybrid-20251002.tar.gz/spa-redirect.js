// SPA redirect helper - disabled for non-GitHub deployments
// This script runs in 404.html to handle client-side routing
(function() {
  // Disabled for Hostinger deployment
  // SPA routing is handled by React Router directly
})();